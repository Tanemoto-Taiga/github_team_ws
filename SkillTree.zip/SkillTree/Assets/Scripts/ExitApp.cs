using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitApp : MonoBehaviour
{
    public void ButtonExit(){
        Application.Quit();
    }
}
